2005-10-24      v1.00

- New interpreter example that shows usage of MochiKit.DOM  to make
  an interactive JavaScript interpreter
- New MochiKit.LoggingPane for use with the MochiKit.Logging
  debuggingBookmarklet, with logging_pane example to show its usage
- New mochiregexp example that demonstrates MochiKit.DOM and MochiKit.Async
  in order to provide a live regular expression matching tool
- Added advanced number formatting capabilities to MochiKit.Format:
  numberFormatter(pattern, placeholder="", locale="default") and
  formatLocale(locale="default")
- Added updatetree(self, obj[, ...]) to MochiKit.Base, and changed
  MochiKit.DOM's updateNodeAttributes(node, attrs) to use it when appropiate.
- Added new MochiKit.DOM createDOMFunc aliases: BUTTON, TT, PRE
- Added truncToFixed(aNumber, precision) and roundToFixed(aNumber, precision)
  to MochiKit.Format
- MochiKit.DateTime can now handle full ISO 8601 timestamps, specifically
  isoTimestamp(isoString) will convert them to Date objects, and
  toISOTimestamp(date, true) will return an ISO 8601 timestamp in UTC
- Fixed missing errback for sendXMLHttpRequest when the server does not
  respond
- Fixed infinite recusion bug when using roundClass("DIV", ...)
- Fixed a bug in MochiKit.Async wait (and callLater) that prevented them
  from being cancelled properly
- Workaround in MochiKit.Base bind (and partial) for functions that don't
  have an apply method, such as alert
- Reliably return null from the string parsing/manipulation functions if
  the input can't be coerced to a string (s + "") or the input makes no sense;
  e.g. isoTimestamp(null) and isoTimestamp("") return null

2005-10-08      v0.90

- Fixed ISO compliance with toISODate
- Added missing operator.sub
- Placated Mozilla's strict warnings a bit
- Added JSON serialization and unserialization support to MochiKit.Base:
  serializeJSON, evalJSON, registerJSON.  This is very similar to the repr
  API.
- Fixed a bug in the script loader that failed in some scenarios when a script
  tag did not have a "src" attribute (thanks Ian!)
- Added new MochiKit.DOM createDOMFunc aliases: H1, H2, H3, BR, HR, TEXTAREA,
  P, FORM
- Use encodeURIComponent / decodeURIComponent for MochiKit.Base urlEncode
  and parseQueryString, when available.

2005-08-12      v0.80

- Source highlighting in all examples, moved to a view-source example
- Added some experimental syntax highlighting for the Rounded Corners example,
  via the LGPL dp.SyntaxHighlighter 1.2.0 now included in examples/common/lib
- Use an indirect binding for the logger conveniences, so that the global
  logger could be replaced by setting MochiKit.Logger.logger to something else
  (though an observer is probably a better choice).
- Allow MochiKit.DOM.getElementsByTagAndClassName to take a string for parent,
  which will be looked up with getElement
- Fixed bug in MochiKit.Color.fromBackground (was using node.parent instead of
  node.parentNode)
- Consider a 304 (NOT_MODIFIED) response from XMLHttpRequest to be success
- Disabled Mozilla map(...) fast-path due to Deer Park compatibility issues
- Possible workaround for Safari issue with swapDOM, where it would get
  confused because two elements were in the DOM at the same time with the
  same id
- Added missing THEAD convenience function to MochiKit.DOM
- Added lstrip, rstrip, strip to MochiKit.Format
- Added updateNodeAttributes, appendChildNodes, replaceChildNodes to
  MochiKit.DOM
- MochiKit.Iter.iextend now has a fast-path for array-like objects
- Added HSV color space support to MochiKit.Visual
- Fixed a bug in the sortable_tables example, it now converts types
  correctly
- Fixed a bug where MochiKit.DOM referenced MochiKit.Iter.next from global
  scope

2005-08-04      v0.70

- New ajax_tables example, which shows off XMLHttpRequest, ajax, json, and
  a little TAL-ish DOM templating attribute language.
- sendXMLHttpRequest and functions that use it (loadJSONDoc, etc.) no longer
  ignore requests with status == 0, which seems to happen for cached or local
  requests
- Added sendXMLHttpRequest to MochiKit.Async.EXPORT, d'oh.
- Changed scrapeText API to return a string by default.  This is API-breaking!
  It was dumb to have the default return value be the form you almost never
  want.  Sorry.
- Added special form to swapDOM(dest, src).  If src is null, dest is removed
  (where previously you'd likely get a DOM exception).
- Added three new functions to MochiKit.Base for dealing with URL query
  strings: urlEncode, queryString, parseQueryString
- MochiKit.DOM.createDOM will now use attr[k] = v for all browsers if the name
  starts with "on" (e.g. "onclick").  If v is a string, it will set it to
  new Function(v).
- Another workaround for Internet "worst browser ever" Explorer's setAttribute
  usage in MochiKit.DOM.createDOM (checked -> defaultChecked).
- Added UL, OL, LI convenience createDOM aliases to MochiKit.DOM
- Packing is now done by Dojo's custom Rhino interpreter, so it's much smaller
  now!

2005-07-29      v0.60

- Beefed up the MochiKit.DOM test suite
- Fixed return value for MochiKit.DOM.swapElementClass, could return
  false unexpectedly before
- Added an optional "parent" argument to
  MochiKit.DOM.getElementsByTagAndClassName
- Added a "packed" version in packed/MochiKit/MochiKit.js
- Changed build script to rewrite the URLs in tests to account for the
  JSAN-required reorganization
- MochiKit.Compat to potentially work around IE 5.5 issues
  (5.0 still not supported).  Test.Simple doesn't seem to work there,
  though.
- Several minor documentation corrections

2005-07-27      v0.50

- Initial Release
