(function () {
    return "empty";
})();
