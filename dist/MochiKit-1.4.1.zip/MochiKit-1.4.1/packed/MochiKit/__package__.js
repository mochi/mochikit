dojo.kwCompoundRequire({
    "common": [
        "MochiKit.MochiKit"
    ]
});
dojo.provide("MochiKit.*");
